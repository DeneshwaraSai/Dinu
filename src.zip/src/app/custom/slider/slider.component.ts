import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { NgDialogAnimationService } from 'ng-dialog-animation';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<SliderComponent>,public dialog: NgDialogAnimationService) {}
  
  ngOnInit(): void {
  }

  onNoClick(): void {
    console.log(this.dialogRef);
    this.dialogRef.close();
  }

  
}
