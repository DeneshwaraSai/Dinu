import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainComponent } from './main.component';
import { SliderModule } from '../slider/slider.module';
import { MatFormFieldModule } from '@angular/material/form-field'
import {MatNativeDateModule} from '@angular/material/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    MainComponent
    ],
  imports: [
    BrowserModule,
    CommonModule,
    SliderModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    MatFormFieldModule
  ],
  exports:[
    MainComponent
  ]
})
export class MainModule { }
