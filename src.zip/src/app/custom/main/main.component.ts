import { Component, OnInit } from '@angular/core';
import { SliderComponent } from '../slider/slider.component';
import { NgDialogAnimationService } from 'ng-dialog-animation';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})

export class MainComponent implements OnInit {
  
  constructor(public dialog:NgDialogAnimationService) {}

  ngOnInit(): void {}

  openDialog(): void {
    const ref = this.dialog.open(SliderComponent,{
      id:"slider",
      height:'100%',
      width:'80%',
      animation:{to:'left'},
      position:{
        top:'0px',
        right:'0px',
        bottom:'0px'
      }
      
    })
  }
}
