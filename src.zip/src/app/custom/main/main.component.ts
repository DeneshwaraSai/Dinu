import { Component, OnInit } from '@angular/core';
import { NgDialogAnimationService } from 'ng-dialog-animation';
import { SliderComponent } from '../slider/slider.component';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})

export class MainComponent implements OnInit {
  
  constructor(public dialog: NgDialogAnimationService) {}

  ngOnInit(): void {}

  openDialog(): void {
    const dialogRef = this.dialog.open(SliderComponent, {
      width: "90%",
      height:'100%',
      animation:{to:"left"},
      position: {top: '0px',
        right: '0px',
        bottom: '0px', }
    });
  }
}
