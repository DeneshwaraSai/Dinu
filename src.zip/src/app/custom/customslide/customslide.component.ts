import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customslide',
  templateUrl: './customslide.component.html',
  styleUrls: ['./customslide.component.scss']
})
export class CustomslideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
