import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomslideComponent } from './customslide.component';

describe('CustomslideComponent', () => {
  let component: CustomslideComponent;
  let fixture: ComponentFixture<CustomslideComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomslideComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomslideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
