import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './custom/header/header.component'
import { PatientHeaderComponent } from './custom/patient-header/patient-header.component';
import { MainComponent } from './custom/main/main.component';

const routes: Routes = [
  {
    path: '',
    component : MainComponent
  },
  {
    path: 'PatientHeader',
    component : PatientHeaderComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
 