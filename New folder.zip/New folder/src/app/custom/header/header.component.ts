import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
 
  datamodel:any = [{}];
  constructor(private router:Router) {
    this.datamodel = this.router.getCurrentNavigation()?.extras.state;
    console.log("This is in HeaderComponent : ",(this.datamodel));
  }

  ngOnInit(): void {
  }

  a:number = 0;
  clicked:boolean = false;
  demo=[
    {
      position_id:"SC1001",
      id:0,
      display_shortcut:"MDS",
      name:"person a",
      dob:"12-12-1999",
      location:"Hyderabad",
      status:"Active"
    },
    {
      position_id:"SC1102",
      id:1,
      name:"person b",
      display_shortcut:"PB",
      dob:"12-12-1998",
      location:"Bangalore",
      status:"Active"
    },
    {
      position_id:"SC1201",
      id:2,
      name:"ILA DENESHWARA SAI",
      display_shortcut:"PC",
      dob:"24-12-1999",
      location:"Chennai",
      status:"Active"
    },
    {
      position_id:"SC1024",
      id:3,
      name:"person d",
      display_shortcut:"PD",
      dob:"12-10-1999",
      location:"Mumbai",
      status:"InActive"
    },
    {
      position_id:"SC2021",
      id:4,
      name:"person e",
      dob:"09-09-1999",
      display_shortcut:"PE",
      location:"Delhi",
      status:"InActive"
    }
  ]

  h:any = this.demo[0];
  
  forward(){
    this.a= this.a + 1;
    //console.warn("Forward : ", this.demo[this.a]);
    this.h = this.demo[this.a];
    console.warn("Forward : ", this.a ," -> ",this.datamodel[this.a])
  }
  backward(){
    this.a= this.a - 1;
    //console.warn("Backword : ", this.a);
    this.h = this.demo[this.a];
    console.warn("Backword : ", this.a ," -> ", this.datamodel[this.a])
  }
}
