import { Component,OnInit,Input } from '@angular/core';
import {SelectionModel} from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { Router,ActivatedRoute } from '@angular/router';

export interface table{
  name: string;
  position: number;
  age: number;
  mobile: number;
  gender:string;
  aadhar:string;
}

const ELEMENT_DATA: table[] = [
  {position: 1, name: 'Ravi A', age: 20,gender:"Male", mobile:9121478754,aadhar:'9876 5444 8765'},
  {position: 2, name: 'Akhil Ch', age: 21,gender:"Female", mobile:8464646445,aadhar:'9876 5444 1234'},
  {position: 3, name: 'John R', age: 22,gender:"Male", mobile:7588546445,aadhar: '9876 1234 8765'},
  {position: 4, name: 'John William', age: 23,gender:"Female", mobile:8875646445,aadhar: '9876 4567 8765'},
  {position: 5, name: 'David E', age: 24,gender:"Male", mobile:8464649945,aadhar: '9876 5444 8766'},
  {position: 6, name: 'Ester Y', age: 25,gender:"Female", mobile:9785554545,aadhar: '5436 5444 8765'},
  {position: 7, name: 'Gopi A', age: 26,gender:"Male", mobile:7875846445,aadhar: '9876 6789 8765'},
  {position: 8, name: 'Pavan B', age: 27,gender:"Female", mobile:7464645458,aadhar: '3456 5444 8765'},
  {position: 9, name: 'Joe Root', age: 28,gender:"Male", mobile:7584646445,aadhar: '9876 8765 8765'},
  {position: 10, name: 'Abkar MD',age: 29,gender:"Female", mobile:7878874589,aadhar: '9876 7638 8765'},
  {position: 11, name: 'Ravi A', age: 20,gender:"Male", mobile:9121478754,aadhar: '1256 5444 8765'},
  {position: 12, name: 'Akhil Ch', age: 21,gender:"Female", mobile:8464646445,aadhar: '3456 8798 8765'},
  {position: 13, name: 'John R', age: 22,gender:"Male", mobile:7588546445,aadhar: '9876 2885 8765'},
  {position: 14, name: 'John William', age: 23,gender:"Female", mobile:8875646445,aadhar: '1111 5444 8765'},
  {position: 15, name: 'David E', age: 24,gender:"Male", mobile:8464649945,aadhar: '9088 5444 8765'},
  {position: 16, name: 'Ester Y', age: 25,gender:"Female", mobile:9785554545,aadhar: '6009 5444 8765'},
  {position: 17, name: 'Gopi A', age: 26,gender:"Male", mobile:7875846445,aadhar: '9876 5444 8765'},
  {position: 18, name: 'Pavan B', age: 27,gender:"Female", mobile:7464645458,aadhar: '7654 5444 8765'},
  {position: 19, name: 'Joe Root', age: 28,gender:"Male", mobile:7584646445,aadhar: '9876 9879 8765'},
  {position: 20, name: 'Abkar MD',age: 29,gender:"Female", mobile:7878874589,aadhar: '9876 87i8 8765'},
];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})

export class TableComponent implements OnInit{

   datapart:table[] = [];

   positionarray:number[] =[]

   @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns: string[] = ['select', 'position', 'name', 'age' ,'gender', 'mobile'];
  dataSource = new MatTableDataSource<table>(ELEMENT_DATA);
  selection = new SelectionModel<table>(true, []);

  constructor(private router:Router){}

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  logSelection(value:string):void
  {
      this.positionarray= [];
      this.datapart = [];
      this.selection.selected.forEach(s => console.log(s.name));
      this.selection.selected.forEach(s =>{ 
          var index = ELEMENT_DATA.map(function(e) { return e.position }).indexOf(s.position);
          this.datapart.push(ELEMENT_DATA[index]);
          this.positionarray.push(s.position);
      });
    

      if(this.datapart.length === 0)
        alert("Nothing is selected");
      else
        this.router.navigate([`${value}`], { state : this.datapart });
  }
}
