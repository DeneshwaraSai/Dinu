import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-header',
  templateUrl: './patient-header.component.html',
  styleUrls: ['./patient-header.component.css']
})


export class PatientHeaderComponent implements OnInit {

  datamodel:any = [];

  a:number = 0;
  zerothIndex = {}
  totalLength:number;
  
  constructor( private router:Router ) {
    this.datamodel = this.router.getCurrentNavigation()?.extras.state;
    this.totalLength = this.datamodel.length;
    this.a = 0; 
    console.log(this.datamodel[0]);    
  }

  h:any = this.datamodel[0];

  ngOnInit(): void {}

  goleft()
  {
     if(this.a<=0){
      this.a = 0;
    }    
    else{
      this.a -= 1;
      this.h = this.datamodel[this.a];
      console.warn("Left -> ",this.a);
    }
  }

  goRight()
  {
    if (this.a>=(this.totalLength-1)){
      this.a = (this.totalLength-1);
    }
    else 
    {
      this.a += 1;
      this.h = this.datamodel[this.a];
      console.warn("Right -> ", this.a);
    }
  }

  backToResults():void{
    this.router.navigate([`${''}`]);
  }
}