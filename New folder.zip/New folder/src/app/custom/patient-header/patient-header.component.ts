import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-header',
  templateUrl: './patient-header.component.html',
  styleUrls: ['./patient-header.component.css']
})


export class PatientHeaderComponent implements OnInit {

  datamodel:any = [];
  elements:any[] =[];
  value:number = 0;
  data:any[]=[];
  totalLength:number;
  
  constructor( private router:Router ) {
    this.datamodel = this.router.getCurrentNavigation()?.extras.state;
    this.totalLength = this.datamodel.length;
    this.value = 0;
    let i=0;
    for(i=0;i<this.totalLength;i++)
    {
        this.elements.push(this.datamodel[i]);
    }   

    console.log(this.elements);
    this.data[this.value] = this.elements[this.value]   
  }


  ngOnInit(): void {}

  goleft()
  {
     if(this.value<=0){
      this.value = 0;
    }    
    else{
      this.value -= 1;
      this.data[this.value] = this.elements[this.value] 
      console.warn("Left -> ",this.value);
    }
  }

  goRight()
  {
    if (this.value>=(this.totalLength-1)){
      this.value = (this.totalLength-1);
    }
    else 
    {
      this.value += 1;
      this.data[this.value] = this.elements[this.value] 
      console.warn("Right -> ", this.value);
    }
  }

  backToResults():void{
    this.router.navigate([`${''}`]);
  }
}