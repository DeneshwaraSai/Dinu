import { Component, OnInit,Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  @Input() istype:any; 
  @Input() title:any;
  @Input() values:any;
  @Input() dataObject:any;
  
  myControl:FormControl;
 
  options = ["Sam", "Varun", "Jasmine"];

  filteredOptions:any;
  formGroup : FormGroup;
  constructor( private fb : FormBuilder){
    this.myControl = new FormControl();
  }
  
  ngOnInit(){
      this.initForm();
      this.getNames();
  }

  initForm(){
    this.formGroup = this.fb.group({
      title : ['']
    })
    

    this.formGroup.get('title')?.valueChanges.pipe().subscribe(response => {
      console.log('entered data is ', response);
      console.log(this.title);
      if(response && response.length){
        this.filterData(response);
      } 
      else {
        this.filteredOptions = [];
      }
    })
  }

  filterData(enteredData:any){
    this.filteredOptions = this.options.filter(item => {
      return item.toLowerCase().indexOf(enteredData.toLowerCase()) > -1
    })
  }

  getNames(){
    this.options = this.dataObject;
  }
}
