import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Toast';

  constructor(private toastr:ToastrService) {}

  success(){
    this.toastr.success("Message","Title\n",
    {
      timeOut:3000,
      progressBar:true,
      progressAnimation:"increasing"
    });
  }

  error(){
    this.toastr.error("Error Message","Title of Error Message",
    {
      timeOut:3000,
      progressBar:true,
      progressAnimation:"increasing"
    });
  }
}
